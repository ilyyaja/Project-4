import java.util.Scanner;
public class testScores {
    private char getLetterGrade(int testScore) {
        char letter = ' ';
        if (testScore >= 90) {
            return 'A';
        } else if (testScore >= 80 && testScore < 90) {
            return 'B';
        } else if (testScore >= 70 && testScore < 80) {
            return 'C';
        } else if (testScore >= 60 && testScore < 70) {
            return 'D';
        } else {
            return 'F';
        } //close for-loop
    }//close method

    public void printGrades(int[] testScores, char[] lettergrade) {
        System.out.println("Score  Grade");
        for (int i = 0; i < testScores.length; i++) {
            lettergrade[i] = getLetterGrade(testScores[i]);
        }
        for (int i = 0; i < testScores.length; i++) {
            System.out.println(testScores[i] + "\t\t" + lettergrade[i]);
        }

    }

    public void printHighestScore(int[] testScores) {
        int max = 0;
        for (int i = 0; i < testScores.length; i++) {
            if (testScores[i] > max) {
                max = testScores[i];

            }
        }

        System.out.println("The Highest Score Is: " + max);
    }
    public void printLowestScore(int[] testScores) {
        int min = 100;
        for (int i = 0; i < testScores.length; i++) {
            if (testScores[i] < min) {
                min = testScores[i];
            }
        }
            System.out.print("The Lowest Score Is: "  + min );
            }
    public void PrintAverageScore (int[] testScores) {
        int sum = 0;
        for(int i = 0; i < testScores.length; i++) {
            sum += testScores[i];
        }
        double average = (double) sum / testScores.length;
        System.out.println("\nThe Average Score Is: " + average);
        }
    }














