import java.util.Random;
import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int numTest = random.nextInt(3, 10);
        int[] array = new int[numTest];
        char[] lettergrades = new char[numTest];
        System.out.printf("Enter your %d test scores\n", numTest);

        for (int i = 0; i < numTest; i++) {
            System.out.println("Enter Test Score " + (i + 1) + ": ");
            int testScore = scanner.nextInt();
            array[i] = testScore;


        }
        testScores grades = new testScores();
        grades.printGrades(array, lettergrades);
        testScores highscore = new testScores();
        highscore.printHighestScore(array);
        testScores lowscore = new testScores();
        lowscore.printLowestScore(array);
        testScores average = new testScores();
        average.PrintAverageScore(array);


        //printLowestScore()
        //printAverageScore()

    }
}

