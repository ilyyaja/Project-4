import java.util.Scanner;
public class ArraysFromInput {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        String[] firstnames = new String[3];
        firstnames[0] = "Naruto";
        firstnames[1] = "Sasuke";
        firstnames[2] = "Sakura";
        

        String[] lastnames = new String[3];
        lastnames[0] = "Uzumaki";
        lastnames[1] = "Uchiha";
        lastnames[2] = "Kokomo";

        int[] powerlevel = new int[3];
        powerlevel[0] = 500;
        powerlevel[1] = 800;
        powerlevel[2] = 200;


        for (int i = 0; i < 3; i++) {
            System.out.print("First name: ");
            firstnames[i] = console.nextLine();
            System.out.print("Last name: ");
            lastnames[i] = console.nextLine();
            System.out.print("Power level: ");
            powerlevel[i] = Integer.parseInt(console.nextLine());
            System.out.println();
        }


        System.out.printf("%-14s %s\n", "Name", "Power level");


        for (int i = 0; i < firstnames.length; i++) {
            System.out.printf("%-14s %d\n", firstnames[i] + " " + lastnames[i], powerlevel[i]);


            }


        }
    }





