import java.util.ArrayList;

public class Bank {
    private ArrayList<Customer> customerArrayList = new ArrayList<>();

    //Methods
    public void addCustomer(Customer customer){
        customerArrayList.add(customer);
    }
    public void removeCustomer(Customer customer){
        customerArrayList.remove(customer);
    }
    public Customer getCustomer(String PIN) {
        Customer foundCustomer = null;
        for (Customer customer: customerArrayList){
            if(customer.getPIN().equals(PIN)){
                foundCustomer = customer;
                break;
            }
        }
        return foundCustomer;
    }
    public StringBuilder getAllCustomerArrayList(){
        StringBuilder customerStringBuilder = new StringBuilder();
        for (Customer customer: customerArrayList) {
            customerStringBuilder.append(customer.toString());

        }
        return customerStringBuilder;
    }
}
