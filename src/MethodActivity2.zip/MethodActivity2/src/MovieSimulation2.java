import java.util.Scanner;

public class MovieSimulation2 {


    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {


        String[] movieNames = {"Star Wars", "Matrix", "Up", "Turning Red"};
        String[] movieTypes = {"2D", "3D", "2D", "2D"};
        double[] moviePrices = {20.25, 15.25, 12.24, 62.32};


        //Mod 1
        final int ROW = 5;
        final int COLUMN = 10;
        int[][] movieAvailability = new int[ROW][COLUMN];
        displayMovieDetails(movieNames, movieTypes, moviePrices);
        int index = selectMovie(movieNames);
        displaySelectedMovie(movieNames[index], movieTypes[index], moviePrices[index]);
        System.out.println();
        System.out.println("----------Random Generated Seats------------");
        System.out.println();
        System.out.println("Seating Availability: [1 = unavailable ; 0 = available]  ");
        System.out.println();
        displaySeatAvailability(movieAvailability);


    }

    static void displaySelectedMovie(String movieName, String type, double price) {
        System.out.println("--------------------Movie Selection------------------");
        System.out.printf("%-20s %-20s %-20s\n", "Movie Name", "Movie Type", "Movie Price");
        System.out.printf("%-20s %-20s %-20.2f\n", movieName, type, price);

    }


    public static void displayMovieDetails(String[] movieNames, String[] movieTypes, double[] moviePrices) {
        System.out.println("---------------------Movie details----------------------");
        System.out.printf("%-20s %-20s %-20s\n", "Movie Names", "Movie Types", "Movie Prices");
        for (int i = 0; i < movieNames.length; i++) {
            System.out.printf("%-20s %-20s %-20.2f\n", movieNames[i], movieTypes[i], moviePrices[i]);
        }
    }

    static int selectMovie(String[] movieName) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("What movie are you seeing? ");
            String userInput = scanner.nextLine();
            for (int i = 0; i < movieName.length; i++) {
                if (userInput.equalsIgnoreCase(movieName[i])) {
                    return i;
                } else {
                    System.out.println("Movie not found. Try again.");
                }
            }
        }
    }

    public static void setSeatAvailability(int mAvail[][]) {
        for (int i = 0; i < mAvail.length; i++) {
            for (int j = 0; j < mAvail[i].length; j++) {
                mAvail[i][j] = 0;

            }
        }
    }

    public static void randomizeAvailability(int mAvail[][]) {
        for (int i = 0; i < mAvail.length; i++) {
            for (int j = 0; j < mAvail[i].length; j++) {
                mAvail[i][j] = (int) (Math.random() * 2);

            }
        }

    }

    public static void displaySeatAvailability(int mAvail[][]) {
        char[] rowLabel = {'A', 'B', 'C', 'D', 'E'};
        for (int i = 1; i <= mAvail[0].length; i++) {
            System.out.printf(" %d ", i);
        }
        System.out.printf("\n %s", "~".repeat(30));
        for (int i = 0; i < mAvail.length; i++) {
            System.out.printf("\n %c |", rowLabel[i]);
            for (int j = 0; j < mAvail[i].length; j++) {
                System.out.print(mAvail[i][j] + "  ");
            }
            System.out.println();
        }
    }


}

